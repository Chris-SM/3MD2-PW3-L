<?php 
session_start();
session_start();
if ($_SESSION['usuario'] != null) {
    echo "aaaaaaaaa";
}



?>